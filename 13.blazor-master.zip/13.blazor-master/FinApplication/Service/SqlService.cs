﻿using FinApplication.Data.Models;
using FinApplication.Data.DB;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace FinApplication.Servises
{
    public class SqlService
    {
        private readonly ApiContext _db;

        public SqlService(ApiContext db)
        {
            _db = db;
        }
        #region Category
        public async Task<List<Category>> GetCategoriesAsync()
        {
            return await _db.Categories.ToListAsync();
        }

        public async Task<Category> GetCategoryByIDAsync(int id)
        {
            Category category = await _db.Categories.FirstOrDefaultAsync(x => x.Id == id);                         
            return category;
        }

        public async Task<ActionResult<Category>> AddCategoryAsync(Category category)
        {
            _db.Categories.Add(category);
            await _db.SaveChangesAsync();
            return category;
        }

        public async Task<ActionResult<Category>> DeleteCategoryAsync(int id)
        {
            Category category = await _db.Categories.FirstOrDefaultAsync(x => x.Id == id);
           
            _db.Categories.Remove(category);
            await _db.SaveChangesAsync();
            return category;
        }

        public async Task<ActionResult<Category>> UpdateCategoryAsync(Category category)
        {
             _db.Categories.Update(category);
            await _db.SaveChangesAsync();
            return category;
        }
        #endregion
        #region Transaction
        public async Task<ActionResult<Transaction>> AddTransactionAsync(Transaction transaction)
        {
            _db.Transactions.Add(transaction);
            await _db.SaveChangesAsync();
            return transaction;
        }

        public async Task<List<Transaction>> GetTransactionsAsync()
        {
            return await _db.Transactions.Include(u=>u.Category)                
                .ToListAsync();
        }

        public async Task<Transaction> GetTransactionByIDAsync(int id)
        {
            Transaction transaction = await _db.Transactions.FirstOrDefaultAsync(x => x.Id == id);
            return transaction;
        }

        public async Task<ActionResult<Transaction>> DeleteTransactionAsync(int id)
        {
            Transaction transaction = await _db.Transactions.FirstOrDefaultAsync(x => x.Id == id);

            _db.Transactions.Remove(transaction);
            await _db.SaveChangesAsync();
            return transaction;
        }

        public async Task<ActionResult<Transaction>> UpdateTransactionAsync(Transaction transaction)
        {
            _db.Transactions.Update(transaction);
            await _db.SaveChangesAsync();
            return transaction;
        }
        #endregion
        #region Reports
        public async Task<Report> GetReportAsync(DateTime forDate, DateTime toDate)
        {
            var transactions = await _db.Transactions.Where(p => p.Date >= forDate && p.Date <= toDate)
                .Include(x => x.Category)
                .Select(p => new TransactionView
                {
                    Data = p.Date,
                    Category = p.Category.Name,                   
                    Value = p.Value                 
                })
                .OrderBy(p => p.Data)
                .ToListAsync();

            var (costs, income) = GetAssets(transactions);

            var report = new Report
            {                
                Transactions = transactions,
                Income = income,
                Costs = costs,
                Profit = income + costs,
            };

            return report;
        }

        private (decimal? costs, decimal? income) GetAssets(List<TransactionView> transactions)
        {
            decimal? income = 0;
            decimal? costs = 0;

            foreach (var value in transactions)
            {
                if (value.Value >= 0)
                {
                    income += value.Value;
                }
                else
                {
                    costs += value.Value;
                }
            };
            return (costs, income);
        }
        #endregion
    }
}
