﻿using AutoMapper;
using FinApplication.Data.Models;

namespace FinApplication.Service
{
    public class TransactionProfile : Profile
    {
        public TransactionProfile()
        {
            CreateMap<Transaction, TransactionDTO>()
                .ForMember(dest => dest.CatId,
                            opt => opt.MapFrom(src => src.CategoryId.ToString()));

            CreateMap<TransactionDTO, Transaction>();
        }
    }
}
