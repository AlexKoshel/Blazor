﻿using System;

namespace FinApplication.Data.Models
{
    public class TransactionView
    {
        public DateTime Data { get; set; }        
        public string Category { get; set; }
        public decimal? Value { get; set; }
        public string Note { get; set; }        
    }
}