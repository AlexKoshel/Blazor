﻿using System.Collections.Generic;

namespace FinApplication.Data.Models
{
    public class Report
    {        
        public List<TransactionView> Transactions { get; set; }        
        public decimal? Income { get; set; }
        public decimal? Costs { get; set; }
        public decimal? Profit { get; set; }
    }
}