﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FinApplication.Data.Models
{
    public class TransactionDTO
    {
        public int Id { get; set; }

        [Required]
        [Range(typeof(DateTime), "01/01/2020", "01/01/2030", ErrorMessage = "Value for {0} must be between {1} and {2}")]
        public DateTime Date { get; set; } = DateTime.Now;

        [Required]
        public int CategoryId { get; set; }

        [Required]
        public string CatId { get; set; } = string.Empty;

        [Required(ErrorMessage = "Value is required")]
        public decimal? Value { get; set; } = null;

        public string Note { get; set; }

        public Category Category { get; set; }
    }
}
